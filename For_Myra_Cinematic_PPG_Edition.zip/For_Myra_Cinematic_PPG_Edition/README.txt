FOR MYRA — CINEMATIC PPG EDITION

Cara menjalankan:
1. Ekstrak ZIP ini.
2. Buka folder For_Myra_Cinematic_No_Photos.
3. Klik dua kali index.html untuk melihat website.
4. Untuk mengirim lewat internet, unggah seluruh isi folder (index.html, css, js, musik, video) ke Netlify atau hosting statis lain.

Isi website:
- Pembukaan cinematic hitam-gold.
- Animasi teks saat tiap bab muncul.
- Navigasi bab dan progress bar.
- Musik instrumental (klik MUSIK OFF/ON; browser mensyaratkan klik pengguna).
- Surat motivasi khusus seminar PPG.
- Video penutup yang sudah disertakan.

Jangan pisahkan folder css, js, musik, dan video dari index.html.
